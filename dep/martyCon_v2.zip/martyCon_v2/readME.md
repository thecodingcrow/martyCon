# Marty the connector

Marty is a professional software tool originally developed for 
JK-Regeltechnik to improve the performance of certain tasks

**Table of Contents**
- What is Marty here for
- How does Marty even work
- How to use Marty

### What is Marty here for

The goal of Marty is to filter a file for certain data points, process and connect them 
and finally write the connection string into another file.

### How does Marty even work

Marty uses simple python string techniques to achieve glamorous results. 

### How to use Marty


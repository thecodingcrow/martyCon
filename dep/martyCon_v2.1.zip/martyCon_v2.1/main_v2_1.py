from utils_v2_1 import *
from tkinter import *

'''
DISCLAIMER

© ME 2021
All rights reserved

In case of malfunction contact author via eli23dex@gmail.com

version: 1.1


______________________________________________________________

TODO: Error handling
TODO: Indexing 
TODO: Custom Send REceive Texts

'''

'''
CONFIG SECTION - Parameters you need to adjust in order to get the script working properly
'''
# input file
dp_csv_filename = "all_dp_error.dpcsv"

# out file
output_filename = "result.csv"

test_abb_one = "UKG0001_TempAdjust"
test_abb_two = "RMC0001MWB"

dp_states = ['Send', 'Receive']

# currently the same index gets set for each line
index = "0x1000"

'''
VARIABLES SECTION - DO NOT TOUCH THESE UNLESS YOU ARE ELIGIBLE 
'''
# utils
dp_helper = DataPointsHelper()
paths_first_abb = list()
paths_sec_abb = list()
names_first_abb = list()
names_sec_abb = list()
last_log = 0

files_loaded = False

# styling
lbl_font = ("Arial Bold", 10)
list_font = ('Arial Bold', 9)
entry_font = ('Arial Bold', 10)
dropd_font = ('Helvetica', 10)
error_font = ('Arial Bold', 12)

# main window
root = Tk()
root.title('MartyCon')
root.geometry('1200x800')
'''
Event handling 
'''


def log(text):
    global last_log

    lst_log.insert(last_log, text)
    last_log += 1


def load_file():
    global files_loaded

    # read all data points from file
    filepath = txt_file.get()
    if not os.path.exists(filepath):
        log(f'{ERROR} Invalid file path specified!')
        return
    dp_helper.get_datapoints_and_config_from_file(dp_csv_filename)

    files_loaded = True
    log(f'{INFO} File loaded successfully')

#
# def origin_state_listener(*args):
#     update_origin_dp(origin_state.get())
#
#
# def dest_state_listener(*args):
#     update_dest_dp(dest_state.get())

#
# def update_dest_dp(new_state):
#     i = lst_dest.curselection()
#     if len(i) is 0:
#         print('You have to select a data point to change its state')
#         return
#
#     selected_dp = lst_dest.get(i)
#     print(selected_dp)
#
#     selected_dp = switch_state(new_state=new_state, dp=selected_dp)
#
#     lst_dest.delete(i)
#     lst_dest.insert(i, selected_dp)
#
#
# def update_origin_dp(new_state):
#     i = lst_origin.curselection()
#     if len(i) is 0:
#         print('You have to select a data point to change its state')
#         return
#
#     selected_dp = lst_origin.get(i)
#     print(selected_dp)
#
#     selected_dp = switch_state(new_state=new_state, dp=selected_dp)
#
#     lst_origin.delete(i)
#     lst_origin.insert(i, selected_dp)
#
#
# def switch_state(new_state, dp):
#     dp_start_index = dp.index('STATE') + 7
#
#     curr_state = dp[dp_start_index:]
#     print(f'dp state {curr_state}, new_state {new_state}')
#
#     if new_state == curr_state:
#         return dp
#     elif new_state == dp_states[0] and curr_state == dp_states[1]:
#         dp = dp.replace(curr_state, dp_states[0])
#     elif new_state == dp_states[1] and curr_state == dp_states[0]:
#         dp = dp.replace(curr_state, dp_states[1])
#
#     curr_state = dp[dp_start_index:]
#     print(f'dp state {curr_state}')
#
#     return dp


def perform_search():
    global files_loaded
    global lst_origin
    global names_first_abb
    global paths_first_abb
    global names_sec_abb
    global paths_sec_abb
    global output_filename

    if not files_loaded:
        lbl_error.configure(text='You have to load a file before starting a search!')
        log(f'{ERROR} You have to load a file before starting a search!')
        return

    abb_1 = txt_abb1.get()
    abb_2 = txt_abb2.get()

    if abb_1 == '' or abb_2 == '' or abb_1 == abb_2:
        lbl_error.configure(text='You have to specify two different abbreviations!')
        log(f'{ERROR} You have to specify two different abbreviations!')
        return

    output_filename = 'Conn_' + abb_1 + '__' + abb_2 + '.csv'
    txt_path.insert(END, os.path.join(output_dir, output_filename))

    log(f'{INFO} New filename specified: {output_filename}')

    found_dps_first_abb = dp_helper.get_dps_from_abb(abb_1)

    # retrieve parameters for found matches (abb_1)
    paths_first_abb = list()
    names_first_abb = list()
    for dp in found_dps_first_abb:
        paths_first_abb.append(get_path_from_dp(dp))
        names_first_abb.append(get_name_from_dp(dp))

    # retrieve dps for second abb
    found_dps_second_abb = list()
    dp_with_no_match = list()

    for i, name in enumerate(names_first_abb):
        try:
            # for dp in dp_helper.get_dp_by_abb_with_same_name(name, abb_1, abb_2):
            #     found_dps_second_abb.append(dp)
            res = dp_helper.get_dp_by_abb_with_same_name(name, abb_1, abb_2)
            found_dps_second_abb.append(res)
        except:
            dp_with_no_match.append(name)
            del_dp_by_name(found_dps_first_abb, name)

    names_first_abb = list()
    paths_first_abb = list()
    for dp in found_dps_first_abb:
        paths_first_abb.append(get_path_from_dp(dp))
        names_first_abb.append(get_name_from_dp(dp))

    log(f'{INFO} Connection Sources - {len(names_first_abb)} possible connection sources:')

    log(f'{INFO} Connection Destination - data points that correspond to Names from {abb_1} and {abb_2}: Found {len(found_dps_second_abb)}')

    # retrieve parameters for found matches (abb_2)
    paths_sec_abb = list()
    names_sec_abb = list()
    for dp in found_dps_second_abb:
        paths_sec_abb.append(get_path_from_dp(dp))
        names_sec_abb.append(get_name_from_dp(dp))

    log(f'{INFO} Found {len(paths_sec_abb)} Names:')

    log(f'{INFO} Found {len(dp_with_no_match)} mismatches')

    # check if length of to be connected lists match
    log(validate_lists(found_dps_first_abb, found_dps_second_abb, 'origin data points'))
    log(validate_lists(names_first_abb, names_sec_abb, 'connection names'))
    log(validate_lists(paths_first_abb, paths_sec_abb, 'connection paths'))

    lst_origin.delete(0, END)
    lst_dest.delete(0, END)

    for i, name in enumerate(names_first_abb):
        lst_name = name + ', STATE: ' + dp_states[0]
        lst_origin.insert(i, lst_name)

    for i, name in enumerate(names_sec_abb):
        lst_name = name + ', STATE: ' + dp_states[1]
        lst_dest.insert(i, lst_name)

    log('Search performed')


def write_res_to_file():
    dp_conn = list()
    for first_path, name, sec_path in zip(paths_first_abb, names_first_abb, paths_sec_abb):
        first_text = get_state_from_origin_dp(names_first_abb.index(name))
        sec_text = get_state_from_dest_dp(names_first_abb.index(name))

        conn_string = get_connection_from_dps(conn_name=name, dest_path=sec_path, orig_path=first_path,
                                              index=index, first_text=first_text, second_text=sec_text)
        dp_conn.append(conn_string)

    # print result to file
    print_connection_to_file(dp_conn, output_filename)

    log(f'{INFO} successfully wrote {len(dp_conn)} connection strings to {output_filename}')


def get_state_from_origin_dp(index):
    dp = lst_origin.get(index)
    dp_start_index = dp.index('STATE') + 7

    return dp[dp_start_index:]


def get_state_from_dest_dp(index):
    dp = lst_dest.get(index)
    dp_start_index = dp.index('STATE') + 7

    return dp[dp_start_index:]


'''
Init Interface
'''
lbl_file = Label(root, text='Select File', font=lbl_font)
lbl_file.place(x=55, y=90)

txt_file = Entry(root, width=25, font=entry_font)
txt_file.place(x=15, y=110)
txt_file.insert(END, dp_csv_filename)

btn_file = Button(root, text="Load File", command=load_file)
btn_file.place(x=103, y=135)

lbl_abb = Label(root, text='Source abb:', font=lbl_font)
lbl_abb2 = Label(root, text='Destination abb:', font=lbl_font)

lbl_abb.place(x=205, y=60)
lbl_abb2.place(x=650, y=60)

txt_abb1 = Entry(root, width=30, font=entry_font)
txt_abb1.place(x=285, y=60)
txt_abb1.insert(END, test_abb_one)

txt_abb2 = Entry(root, width=30, font=entry_font)
txt_abb2.place(x=765, y=60)
txt_abb2.insert(END, test_abb_two)

txt_path = Entry(root, width=59, font=entry_font)
txt_path.place(x=650, y=720)
txt_path.insert(END, os.path.join(output_dir, output_filename))

btn_conn = Button(root, text="Search", command=perform_search)
btn_conn.place(x=70, y=200)

btn_write = Button(root, text="Write to file", command=write_res_to_file)
btn_write.place(x=950, y=750)

lst_origin = Listbox(root, font=list_font)
lst_origin.place(x=200, y=100, width=420, height=480)

lst_dest = Listbox(root, font=list_font)
lst_dest.place(x=650, y=100, width=420, height=480)

lbl_error = Label(root, font=error_font, width=50, text='Dummy Error for testing purposes')
lbl_error.place(x=132, y=600)

lst_log = Listbox(root, font=list_font)
lst_log.place(x=200, y=600, width=873, height=90)
#
# origin_state = StringVar(root)
# origin_state.set(dp_states[0])
#
# dest_state = StringVar(root)
# dest_state.set(dp_states[0])
#
# opt = OptionMenu(root, origin_state, *dp_states)
# opt.config(font=dropd_font)
# opt.place(x=20, y=80)
#
# opt = OptionMenu(root, dest_state, *dp_states)
# opt.config(font=dropd_font)
# opt.place(x=20, y=180)
#
# origin_state.trace('w', origin_state_listener)
# dest_state.trace('w', dest_state_listener)

root.mainloop()
